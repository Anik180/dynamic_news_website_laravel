
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1 class="m-0 text-dark">Edit District</h1>
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
               <li class="breadcrumb-item active"><a href="<?php echo e(route('district')); ?>">Sub District</a></li>
               <li class="breadcrumb-item active">Edit District</li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
<div class="card">
   <div class="card-header">
      <h3 class="card-title">District Modify</h3>
   </div>
   <!-- /.card-header -->
   <div class="card-body">
      <div class="modal-content modal-dialog" >
         <div class="modal-header">
            <h4 class="modal-title">Update District  </h4>
         </div>
         <div class="modal-body">
            <form method="POST" action="<?php echo e(route('update.district',$district->id)); ?>">
               <?php echo csrf_field(); ?>
               <div class="card-body">
                  <div class="form-group">
                     <label >Division</label>
                     <select class="form-control <?php $__errorArgs = ['division_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="division_id" required>
                        <option disabled=""selected="">Select One</option>
                        <?php $__currentLoopData = $division; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($row->id); ?>" <?php if($row->id==$district->division_id)
                           echo "selected";
                           ?>><?php echo e($row->division_en); ?>|<?php echo e($row->division_bn); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                  </div>
                  <div class="form-group">
                     <label >District Name English</label>
                     <input type="text"  class="form-control" value="<?php echo e($district->district_en); ?>" name="district_en"  required="">
                  </div>
                  <div class="form-group">
                     <label >District Name Bangla</label>
                     <input type="text" class="form-control" value="<?php echo e($district->district_bn); ?>" name="district_bn" required="">
                  </div>
                  <div class="form-group mb-0">
                  </div>
               </div>
               <!-- /.card-body -->
               <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Update</button>
               </div>
            </form>
         </div>
      </div>
   </div>
   <!-- /.card-body -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news\resources\views/backend/district/edit.blade.php ENDPATH**/ ?>