

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Edit Sub Categories</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
              <li class="breadcrumb-item active"><a href="<?php echo e(route('subcategory')); ?>">Sub Categories</a></li>
                 <li class="breadcrumb-item active">Edit Sub Categories</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>


     <div class="card">
            <div class="card-header">
              <h3 class="card-title">Category Sub Modify</h3>
           

            </div>
            <!-- /.card-header -->
            <div class="card-body">
                      <div class="modal-content modal-dialog" >
            <div class="modal-header">
              <h4 class="modal-title">Update Sub Category  </h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                  <form method="POST" action="<?php echo e(route('update.subcategory',$subcategory->id)); ?>">
                    <?php echo csrf_field(); ?>
                <div class="card-body">
                     <div class="form-group">
                    <label >Category</label>
                     
                  <select class="form-control <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="category_id" required> 
                      <option disabled=""selected="">Select One</option>
                      <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($row->id); ?>" <?php if($row->id==$subcategory->category_id)
                      echo "selected";
                      ?>><?php echo e($row->category_en); ?>|<?php echo e($row->category_bn); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                 
                  </div>
                  <div class="form-group">
                    <label >Sub Category Name English</label>
                      
                    <input type="text"  class="form-control" value="<?php echo e($subcategory->subcategory_en); ?>" name="subcategory_en" placeholder="Enter Sub Category Name English" required="">
                  </div>
                  <div class="form-group">
                    <label >Sub Category Name Bangla</label>
                  
                    <input type="text" class="form-control" value="<?php echo e($subcategory->subcategory_bn); ?>" name="subcategory_bn" placeholder="Enter Sub Category Name Bangla" required="">
                  </div>
                  <div class="form-group mb-0">
               
                  </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </form>
            </div>
           
          </div>
            </div>
            <!-- /.card-body -->
          </div>



   
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news\resources\views/backend/subcategory/edit.blade.php ENDPATH**/ ?>