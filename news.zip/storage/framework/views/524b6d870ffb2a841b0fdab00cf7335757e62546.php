
<?php $__env->startSection('content'); ?>
<style type="text/css">
   .submenu a{
   font-size: 18px;
   }
   .submenu a li{
   list-style-type: none;
   display: inline-block;
   padding:5px 15px;
   background: #E5E5E5;
   color: #000;
   margin-right: 10px;
   }
   .submenu a li:hover{
   background: #f4f4f4;
   }
</style>
<div class="col-sm-12 col-12">
   <div class="container" style="padding: 0;">
      <div class="col-sm-12 col-12" style="padding-top: 50px; ">
         <div class="scrollmenu">
            <a href="#">#</a>
         </div>
      </div>
      <!--     <div class="col-sm-12 col-12" id="headtitle">
         <div class="row">
           <div class="col-sm-3 col-4" id="headname">
             <center><a href="#" class="link">স্থানীয়</a></center>      
           </div>   
         </div>
         </div> -->
      <div class="row">
         <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php
         $slug=preg_replace('/\s+/u','-',trim($row->title_bn));
         ?>
         <div class="col-sm-4 col-12 mt-5">
            <div class="col-sm-12 col-12" id="newstop">
               <div class="img-hover-zoom">   
                  <a href="<?php echo e(URL::to('view-post/'.$row->id.'/'.$slug)); ?>">
                  <img src="<?php echo e(asset($row->image)); ?>" style="height:200px; width:100%; filter:saturate(1.5);" class="img-fluid">
                  </a>
               </div>
               <div style="margin-top: 3px;">
                  <a href="#" class="smalllink">
                  <?php echo e($row->category_bn); ?>

                  </a><br>     
               </div>
               <div style="margin-top: 10px;">
                  <a href="<?php echo e(URL::to('view-post/'.$row->id.'/'.$slug)); ?>" class="h5"><?php echo e($row->title_bn); ?></a>
               </div>
               <div>
               </div>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <!----------------------------End card----------------------------->
      </div>
      <?php echo e($post->links()); ?>

   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news\resources\views/fronend/subindex.blade.php ENDPATH**/ ?>