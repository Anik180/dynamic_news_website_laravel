<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Image;
class AdsController extends Controller
{
      public function __construct()
    {
        $this->middleware('auth');
    }
    public function ads()
    {
    	$ads=DB::table('advertiesments')->get();
    	return view('backend.ads.index',compact('ads'));
    }

    public function storeads(Request $request)
    {
    $data=array();
    $data['link']=$request->link;
    if($request->type==2)
    {
    $image=$request->ads;
    $image_one=uniqid().'.'.$image->getClientOriginalExtension();
    Image::make($image)->resize(980,90)->save('public/ads/'.$image_one);
    $data['ads']='public/ads/'.$image_one;
    $data['type']=2;
    DB::table('advertiesments')->insert($data);
    $notification=array(
    'messege'=>'Successfully Added',
    'alert-type'=>'success'
                  );
    return Redirect()->back()->with($notification);
    }else{
 	$image=$request->ads;
    $image_one=uniqid().'.'.$image->getClientOriginalExtension();
    Image::make($image)->resize(700,700)->save('public/ads/'.$image_one);
    $data['ads']='public/ads/'.$image_one;
    $data['type']=1;
    DB::table('advertiesments')->insert($data);
    $notification=array(
    'messege'=>'Successfully Added',
    'alert-type'=>'success'
                  );
    return Redirect()->back()->with($notification);

 }

    }

    public function deleteads($id)
    {
    	$post=DB::table("advertiesments")->where('id',$id)->first();
        unlink($post->ads);
        DB::table("advertiesments")->where('id',$id)->delete();
        $notification=array(
        'messege'=>'Successfully Delete Advertiesment',
        'alert-type'=>'success'
        );
        return Redirect()->back()->with($notification);
    }

    public function editads($id)
    {
    	$edit=DB::table('advertiesments')->where('id',$id)->get();
    	return view('backend.ads.edit',compact('edit'));
    }
}
