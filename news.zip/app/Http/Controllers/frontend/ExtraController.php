<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
class ExtraController extends Controller
{
   public function allpostcat($id,$category_bn)
        {
             $post=DB::table('posts')
            ->join('users','posts.user_id','users.id')
            ->join('categories','posts.category_id','categories.id')
            ->select('posts.*','users.name','categories.category_bn')
            ->where('category_id',$id)->orderBy('id','DESC')->paginate(16);
            return view('fronend.subindex',compact('post'));
        }
          public function allpost($id,$category_bn)
        {
             $post=DB::table('posts')
                 ->join('users','posts.user_id','users.id')
            ->join('categories','posts.category_id','categories.id')
            ->select('posts.*','users.name','categories.category_bn')
            ->where('category_id',$id)->orderBy('id','DESC')->paginate(16);
            return view('fronend.subindex',compact('post'));
}

        public function singlepost($id,$slug)
        {
        $post=DB::table('posts')
            ->join('categories','posts.category_id','categories.id')
            // ->join('subcategories','posts.subcategory_id','subcategories.id')
            ->join('users','posts.user_id','users.id')
            ->select('posts.*','categories.category_bn','categories.category_en','users.name')
           ->where('posts.id',$id)
           ->first();

       return view('fronend.singlepost',compact('post'));
        }
}
